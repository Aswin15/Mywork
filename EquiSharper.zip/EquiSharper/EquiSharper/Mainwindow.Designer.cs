﻿namespace EquiSharper
{
    partial class Mainwindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainpanel = new System.Windows.Forms.Panel();
            this.querybox = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnchecksyntax = new System.Windows.Forms.Button();
            this.lblquery = new System.Windows.Forms.Label();
            this.btncodingstandard = new System.Windows.Forms.Button();
            this.btnoptimizer = new System.Windows.Forms.Button();
            this.Syntaxpanel = new System.Windows.Forms.Panel();
            this.lblhderrorlist = new System.Windows.Forms.Label();
            this.btnbackhome = new System.Windows.Forms.Button();
            this.lblErrorlist_syntax = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.checksyntaxbox = new System.Windows.Forms.TextBox();
            this.lblheadsyntax = new System.Windows.Forms.Label();
            this.btnclear = new System.Windows.Forms.Button();
            this.mainpanel.SuspendLayout();
            this.Syntaxpanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainpanel
            // 
            this.mainpanel.Controls.Add(this.btnclear);
            this.mainpanel.Controls.Add(this.querybox);
            this.mainpanel.Controls.Add(this.textBox1);
            this.mainpanel.Controls.Add(this.btnchecksyntax);
            this.mainpanel.Controls.Add(this.lblquery);
            this.mainpanel.Controls.Add(this.btncodingstandard);
            this.mainpanel.Controls.Add(this.btnoptimizer);
            this.mainpanel.Location = new System.Drawing.Point(39, 58);
            this.mainpanel.Name = "mainpanel";
            this.mainpanel.Size = new System.Drawing.Size(1308, 452);
            this.mainpanel.TabIndex = 4;
            // 
            // querybox
            // 
            this.querybox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.querybox.Location = new System.Drawing.Point(442, 69);
            this.querybox.Multiline = true;
            this.querybox.Name = "querybox";
            this.querybox.Size = new System.Drawing.Size(754, 186);
            this.querybox.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(442, 69);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(754, 186);
            this.textBox1.TabIndex = 4;
            // 
            // btnchecksyntax
            // 
            this.btnchecksyntax.Location = new System.Drawing.Point(442, 330);
            this.btnchecksyntax.Name = "btnchecksyntax";
            this.btnchecksyntax.Size = new System.Drawing.Size(132, 73);
            this.btnchecksyntax.TabIndex = 1;
            this.btnchecksyntax.Text = "Check Syntax";
            this.btnchecksyntax.UseVisualStyleBackColor = true;
            this.btnchecksyntax.Click += new System.EventHandler(this.btnchecksyntax_Click);
            // 
            // lblquery
            // 
            this.lblquery.AutoSize = true;
            this.lblquery.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquery.Location = new System.Drawing.Point(208, 144);
            this.lblquery.Name = "lblquery";
            this.lblquery.Padding = new System.Windows.Forms.Padding(4);
            this.lblquery.Size = new System.Drawing.Size(188, 34);
            this.lblquery.TabIndex = 3;
            this.lblquery.Text = "Enter SQL query ";
            // 
            // btncodingstandard
            // 
            this.btncodingstandard.Location = new System.Drawing.Point(768, 330);
            this.btncodingstandard.Name = "btncodingstandard";
            this.btncodingstandard.Size = new System.Drawing.Size(132, 73);
            this.btncodingstandard.TabIndex = 2;
            this.btncodingstandard.Text = "Check Coding Standards";
            this.btncodingstandard.UseVisualStyleBackColor = true;
            this.btncodingstandard.Click += new System.EventHandler(this.btncodingstandard_Click);
            // 
            // btnoptimizer
            // 
            this.btnoptimizer.Location = new System.Drawing.Point(1064, 330);
            this.btnoptimizer.Name = "btnoptimizer";
            this.btnoptimizer.Size = new System.Drawing.Size(132, 73);
            this.btnoptimizer.TabIndex = 2;
            this.btnoptimizer.Text = "Query Optimizer";
            this.btnoptimizer.UseVisualStyleBackColor = true;
            // 
            // Syntaxpanel
            // 
            this.Syntaxpanel.Controls.Add(this.lblhderrorlist);
            this.Syntaxpanel.Controls.Add(this.btnbackhome);
            this.Syntaxpanel.Controls.Add(this.lblErrorlist_syntax);
            this.Syntaxpanel.Controls.Add(this.textBox2);
            this.Syntaxpanel.Controls.Add(this.checksyntaxbox);
            this.Syntaxpanel.Location = new System.Drawing.Point(40, 54);
            this.Syntaxpanel.Name = "Syntaxpanel";
            this.Syntaxpanel.Size = new System.Drawing.Size(1305, 516);
            this.Syntaxpanel.TabIndex = 5;
            // 
            // lblhderrorlist
            // 
            this.lblhderrorlist.AutoSize = true;
            this.lblhderrorlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhderrorlist.Location = new System.Drawing.Point(41, 242);
            this.lblhderrorlist.Name = "lblhderrorlist";
            this.lblhderrorlist.Size = new System.Drawing.Size(84, 24);
            this.lblhderrorlist.TabIndex = 4;
            this.lblhderrorlist.Text = "Error List";
            // 
            // btnbackhome
            // 
            this.btnbackhome.Location = new System.Drawing.Point(505, 468);
            this.btnbackhome.Name = "btnbackhome";
            this.btnbackhome.Size = new System.Drawing.Size(103, 33);
            this.btnbackhome.TabIndex = 3;
            this.btnbackhome.Text = "Back";
            this.btnbackhome.UseVisualStyleBackColor = true;
            this.btnbackhome.Click += new System.EventHandler(this.btnbackhome_Click);
            // 
            // lblErrorlist_syntax
            // 
            this.lblErrorlist_syntax.AutoSize = true;
            this.lblErrorlist_syntax.Location = new System.Drawing.Point(72, 297);
            this.lblErrorlist_syntax.Name = "lblErrorlist_syntax";
            this.lblErrorlist_syntax.Size = new System.Drawing.Size(0, 13);
            this.lblErrorlist_syntax.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(44, 281);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(1131, 175);
            this.textBox2.TabIndex = 1;
            // 
            // checksyntaxbox
            // 
            this.checksyntaxbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checksyntaxbox.Location = new System.Drawing.Point(44, 55);
            this.checksyntaxbox.Multiline = true;
            this.checksyntaxbox.Name = "checksyntaxbox";
            this.checksyntaxbox.Size = new System.Drawing.Size(754, 159);
            this.checksyntaxbox.TabIndex = 0;
            // 
            // lblheadsyntax
            // 
            this.lblheadsyntax.AutoSize = true;
            this.lblheadsyntax.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblheadsyntax.Location = new System.Drawing.Point(85, 42);
            this.lblheadsyntax.Name = "lblheadsyntax";
            this.lblheadsyntax.Size = new System.Drawing.Size(125, 24);
            this.lblheadsyntax.TabIndex = 4;
            this.lblheadsyntax.Text = "Check Syntax";
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(442, 277);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(84, 29);
            this.btnclear.TabIndex = 5;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // Mainwindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1386, 592);
            this.Controls.Add(this.lblheadsyntax);
            this.Controls.Add(this.mainpanel);
            this.Controls.Add(this.Syntaxpanel);
            this.Name = "Mainwindow";
            this.Text = "EquiSharper";
            this.Load += new System.EventHandler(this.Mainwindow_Load);
            this.mainpanel.ResumeLayout(false);
            this.mainpanel.PerformLayout();
            this.Syntaxpanel.ResumeLayout(false);
            this.Syntaxpanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel mainpanel;
        private System.Windows.Forms.Panel Syntaxpanel;
        private System.Windows.Forms.TextBox checksyntaxbox;
        private System.Windows.Forms.TextBox querybox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnchecksyntax;
        private System.Windows.Forms.Label lblquery;
        private System.Windows.Forms.Button btncodingstandard;
        private System.Windows.Forms.Button btnoptimizer;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblErrorlist_syntax;
        private System.Windows.Forms.Button btnbackhome;
        private System.Windows.Forms.Label lblheadsyntax;
        private System.Windows.Forms.Label lblhderrorlist;
        private System.Windows.Forms.Button btnclear;
    }
}

