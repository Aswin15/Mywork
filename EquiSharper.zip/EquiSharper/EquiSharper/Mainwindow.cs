﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EquiSharper
{
    public partial class Mainwindow : Form
    {
        List<Panel> listPanel = new List<Panel>();
        public Mainwindow()
        {
            InitializeComponent();
        }

        private void btnchecksyntax_Click(object sender, EventArgs e)
        {
            bool queryboxvalue = validentry(querybox.Text);            
            if (queryboxvalue)
            {
                Loadsyntaxpanel();
            }
        }

        private void btncodingstandard_Click(object sender, EventArgs e)
        {

        }

        private void Mainwindow_Load(object sender, EventArgs e)
        {
            lblheadsyntax.Hide();
            btnbackhome.Hide();
            lblhderrorlist.Hide();
            listPanel.Add(mainpanel); 
            listPanel.Add(Syntaxpanel);
            listPanel[0].BringToFront();
        }
        private bool validentry( string value)
        {
            if(string.IsNullOrEmpty(value.Trim()))
            {
                MessageBox.Show("Please enter a valid sql query in textbox", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void btnbackhome_Click(object sender, EventArgs e)
        {
            Syntaxpanel.Hide();
            mainpanel.Show();
            lblheadsyntax.Hide();
            lblhderrorlist.Hide();
            btnbackhome.Hide();
        }
        private void Loadsyntaxpanel()
        {
            lblheadsyntax.Show();
            lblhderrorlist.Show();
            mainpanel.Hide();
            Syntaxpanel.Show();
            btnbackhome.Show();
            //copy content to syntax box
            checksyntaxbox.Text = querybox.Text;
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            querybox.Text = string.Empty;
        }
    }
}
