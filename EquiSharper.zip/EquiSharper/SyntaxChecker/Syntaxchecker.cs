﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyntaxChecker
{
    public class Syntaxchecker
    {
        private string querytext_;
        public string Querytext
        {
            get
            {
                return querytext_;
            }
            set
            {
                querytext_ = value;
            }
        }
        public Syntaxchecker()
        {
            querytext_ = null;
        }
        protected void Rule1()
        {

        }

    }
}
